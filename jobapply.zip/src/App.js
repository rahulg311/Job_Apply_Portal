import logo from './logo.svg';
import './App.css';

import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import About from './About';
import Login from './Login';
import Register from './Pages/Register';
import RegStep2 from './Pages/RegStep2';
import EmployerDashboard from './Pages/EmployerDashboard';
import Navbaar from './Pages/Navbaar';
import EmployeReg from './Pages/EmployeReg';
import EmployeReg2 from './Pages/EmployeReg2';
import Card from './Component/JobCard';
import JobDetails from './Component/JobDetails';
import HomePage from './Pages/HomePage';
import Footer from './Pages/Footer';
import JobSearch from './Pages/JobSearch';
import EmployersProfile from './Pages/EmployersProfile';
import Abouts from './Pages/Abouts';
import TermCondation from './Pages/TermCondation';



function App() {
  return (
    
    <BrowserRouter>
     <Routes>
        <Route index element={<HomePage />} />
        {/* <Route index element={<Login />} /> */}
        <Route path="Signin" element={<Login />} />
        <Route path="About" element={<About />} />
        <Route path="Register" element={<Register />} />
        <Route path="RegStep2" element={<RegStep2 />} />
        <Route path="Navbaar" element={<Navbaar />}/>
        {/* <Route path="HomePage" element={<HomePage />} /> */}
        
        <Route path='EmployeReg' element={<EmployeReg />} />
        <Route path='EmployerReg2' element={<EmployeReg2/>} />
        <Route path="EmployerDashboard" element={<EmployerDashboard />} />
        <Route path="JobDetails" element={<JobDetails />} />
        <Route path="Footer" element={<Footer />} />
        <Route path="JobSearch" element={<JobSearch />} />
        <Route path="Abouts" element={<Abouts/>} />
        <Route path="TermCondation" element={<TermCondation/>} />
        
          <Route path="EmployersProfile" element={<EmployersProfile />} />        
        </Routes>
     </BrowserRouter>
  );
}

export default App;
