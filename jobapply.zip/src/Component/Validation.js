import React from 'react';
import { toast } from "react-toastify";

const Valoidation = (data) => {
  for (let key in data) {
    console.log("data[key]-----",key,data[key])
    if (data.hasOwnProperty(key) && data[key] == "" ) {
      toast.error(`please insert ${key} `);
      return false;
    }
  }

  return true;
};

export default Valoidation;
