import React, { useState } from 'react';
import loginImg from "./images/signup-image.jpg"
import SignINimg from "./images/signin-image.jpg"
import { Button, Checkbox, Form, Input, Modal } from 'antd';
import { EyeInvisibleOutlined, EyeTwoTone, UserOutlined } from '@ant-design/icons';

import { useNavigate } from 'react-router-dom';


const Login = () => {
  let navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const showModal = () => {
    setOpen(true);
  };
  const handleOk = () => {
    setOpen(false);
  };
  const handleCancel = () => {
    setOpen(false);
  };

  const popubmodel = () => {


    return (
      <>
        {/* <Button type="primary" onClick={showModal}>
          Open Modal with customized button props
        </Button> */}
        <Modal
          title="Choose the Registration"
          open={open}
          onOk={handleOk}
          onCancel={handleCancel}
          okButtonProps={{
            disabled: true,
            hidden: true
          }}
          cancelButtonProps={{
            disabled: true,
            hidden: true
          }}
          
        >
          <div className='row'>
            <div className='col-md-6 col-12'>
            <a onClick={() => navigate("/EmployeReg")}>
              <figure class="snip1176"><img className='popup-Img-S' src="https://assets.entrepreneur.com/content/3x2/2000/20160718032444-shutterstock-370385141.jpeg" alt="sample80" />
                <figcaption >
                  <div class="icon"><span><i class="ion-ios-star-outline"></i></span></div>
                  <h5 className='m-3'>Employee</h5>
                  <div class="caption">
                    <p>Regeister with Employee </p>
                  </div>
                </figcaption>
              </figure></a>
            </div>
            <div className='col-md-6 col-12'>
            <a onClick={() => navigate("/Register")}>
              <figure class="snip1176"><img className='popup-Img-S' src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzuqqiFRpTdOR7ZAQ6nPxKvGPUTX4TpE-SZQ&usqp=CAU" alt="sample80" />
                <figcaption >
                  <div class="icon"><span><i class="ion-ios-star-outline"></i></span></div>
                  <h5 className='m-3'>Employer</h5>
                  <div class="caption">
                    <p>Regeister with Employer</p>
                  </div>
                </figcaption>
              </figure></a>
            </div>
          </div>


        </Modal>
      </>)
  }


  return (
    <div className='vh-'>
      <div class="main skill-bg vh-100">
        {/* <!-- Sing in  Form --> */}
        <section class="sign-in">
          <div class="containers mt-5">
            {popubmodel()}
            <div class="signin-content">
              <div class="signin-image">
                <figure><img src={SignINimg} alt="sing up image" /></figure>
                {/* <Button type="primary" onClick={showModal}>
          Open Modal with customized button props
        </Button> */}
                <Button onClick={showModal} class="signup-image-link">Create an account</Button>

              </div>


              <div class="signin-form">
                <h2 class="form-title">Sign In</h2>
                <Form.Item className="mb-1" label="UserName">
                  <Input className='' placeholder="default size" prefix={<UserOutlined />} />
                </Form.Item>

                <Form.Item className="mb-1" label="Password">
                  <Input.Password className='mb-3' placeholder="input password" />
                </Form.Item>
                <Checkbox className='mb-3' >Remember me</Checkbox>
                <div className="col-md-12 col-12 mt-2">
                  <Button onClick={() => navigate("/EmployerDashboard")} className="float-end bg-primary text-white">Login</Button>
                </div>

                <div class="social-login">
                  <span class="social-label">Or login with</span>
                  <ul class="socials">
                    <li><a href="#"><i class="display-flex-center zmdi zmdi-facebook"></i></a></li>
                    <li><a href="#"><i class="display-flex-center zmdi zmdi-twitter"></i></a></li>
                    <li><a href="#"><i class="display-flex-center zmdi zmdi-google"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default Login;
