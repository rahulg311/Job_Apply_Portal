import React, { useState } from 'react';
import { Button, Input, Popconfirm } from "antd";

import { Space, Tag,Table } from 'antd';
import { useNavigate } from 'react-router-dom';
import Navbaar from './Navbaar';
const columns = [
    {
      title: 'Edit',
        dataIndex: 'Edit',
        key: 'Edit',
        render: (Edit) => <a><span className="material-icons fs-4 link-success">
        edit
      </span></a>,
      },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    render: (text) => <a>{text}</a>,
  },
  {
    title: 'Age',
    dataIndex: 'age',
    key: 'age',
  },
  {
    title: 'Address',
    dataIndex: 'address',
    key: 'address',
  },
  {
    title: 'Tags',
    key: 'tags',
    dataIndex: 'tags',
    render: (_, { tags }) => (
      <>
        {tags.map((tag) => {
          let color = tag.length > 5 ? 'geekblue' : 'green';
          if (tag === 'loser') {
            color = 'volcano';
          }
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          );
        })}
      </>
    ),
  },
  {
    title: 'Action',
    key: 'action',
    render: (_, record) => (
      <Space size="middle">
        <a>Invite {record.name}</a>
        <a>Delete</a>
      </Space>
    ),
  },
];
const data = [
  {
    key: '1',
    name: 'John Brown',
    age: 32,
    address: 'New York No. 1 Lake Park',
    tags: ['nice', 'developer'],
  },
  {
    key: '2',
    name: 'Jim Green',
    age: 42,
    address: 'London No. 1 Lake Park',
    tags: ['loser'],
  },
  {
    key: '3',
    name: 'Joe Black',
    age: 32,
    address: 'Sydney No. 1 Lake Park',
    tags: ['cool', 'teacher'],
  },
];

const EmployerDashboard = () => {
    let navigate = useNavigate();
    const[ViewMasterAllUser, setViewMasterAllUser]= useState("")
    return (
    <div>
    <Navbaar/>
      <div className="container-fluid">
      <div className="row my-2">
      <div className="col-md-12 col-12 mt-2"> 
        <h5 className="p-2 mt-2 float-start">Employer dashboard</h5>
        <Button onClick={()=>navigate("/RegStep2")} className="float-end bg-primary text-white me-4">Add Opening </Button> </div>
        <div className="col-md-12 col-12">
        <div className="card my-2 mt-1  p-3 ">
        <div className="row">
        <div className="col-md-12 col-12">
        <Table scroll={{ x: "300" }} columns={columns} dataSource={data} />
        </div>
        </div>
        </div>
        </div>
      </div>
    </div>
    </div>
  );
}

export default EmployerDashboard;























