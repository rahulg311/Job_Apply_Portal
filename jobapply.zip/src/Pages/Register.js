import { PlusOutlined } from "@ant-design/icons";
import React, { useState } from "react";
import {
  Button,
  Cascader,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Slider,
  Switch,
  TreeSelect,
  Upload,
  Steps,
} from "antd";
import { useNavigate } from "react-router-dom";
import ProgressStep from "../Component/ProgressStep";
const Step = Steps.Step;
const { RangePicker } = DatePicker;
const { TextArea } = Input;
const normFile = (e) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e?.fileList;
};
const Register = () => {
  let navigate = useNavigate();
  const navigateNextPage = () => {
    console.log("clik");
    // 👇️ navigate to /
    navigate("/RegStep2");
  };
  const [componentDisabled, setComponentDisabled] = useState(false);
  return (
    <div className="vh-100 skill-bg">
      <div className="row m-0 p-0 d-flex justify-content-center ">
        <div className="col-md-8 col-12">
          <div className="card card-shadow my-3 px-3    my-5">
            <div className="row my-2">
              <div className="col-md-12 col-12">
                <ProgressStep step={0} />
                <h5 className="">Profile Registration</h5>
                <div className="card my-2  p-2 ">
                  <div className="row">
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item className="mb-1" label="Industry - Health ">
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>
                        <Form.Item className="mb-1" label="Name  ">
                          <Input />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Phone No  ">
                          <Input />
                        </Form.Item>

                        <Form.Item className="mb-1" label="City ">
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>

                        <Form.Item className="mb-1" label="Organisation  ">
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-1"
                          label="Name of the contact person/HR  "
                        >
                          <Input />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Email  ">
                          <Input />
                        </Form.Item>

                        <Form.Item className="mb-1" label="Countary ">
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>

                        <Form.Item className="mb-1" label="Location  ">
                          <Input />
                        </Form.Item>
                        <Form.Item
                          className="mb-1"
                          label="Web link of the Organisation  "
                        >
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-0 p-0 "
                          label="Upload"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                        >
                          <Upload
                            className="float-end mb-0 p-0 h_100"
                            action="/upload.do"
                            listType="picture-card"
                          >
                            <div>
                              <PlusOutlined />
                              <div
                                style={{
                                  marginTop: 8,
                                }}
                              >
                                Upload
                              </div>
                            </div>
                          </Upload>
                        </Form.Item>
                        <Form.Item className="mb-1" label="Responsibilities">
                          <Input />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Benefits for employ">
                          <Input />
                        </Form.Item>{" "}
                      </Form>
                    </div>

                    <div className="col-md-12 col-12">
                      <Button
                        onClick={navigateNextPage}
                        className="float-end bg-primary text-white"
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Register;
