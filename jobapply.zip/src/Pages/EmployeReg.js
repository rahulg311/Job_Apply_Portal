import { PlusOutlined,LoadingOutlined } from "@ant-design/icons";
import React, { useState } from "react";
import { message,Button,Cascader,Checkbox,DatePicker,Form,Input,InputNumber,Radio,Select,Slider,Switch,TreeSelect,Upload,Steps, Space} from "antd";
import { useNavigate } from "react-router-dom";
import ProgressStep from "../Component/ProgressStep";
//  profile pic uploade 1
const normFile = (e) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e?.fileList;
};

//  profile pic uploade 2
const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
};
const beforeUpload = (file) => {
  const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
  if (!isJpgOrPng) {
    message.error('You can only upload JPG/PNG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJpgOrPng && isLt2M;
};


const EmployeReg = () => {
    const [loading, setLoading] = useState(false);
    const [imageUrl, setImageUrl] = useState();
    const handleChange = (info) => {
      if (info.file.status === 'uploading') {
        setLoading(true);
        return;
      }
      if (info.file.status === 'done') {
        // Get this url from response in real world.
          getBase64(info.file.originFileObj, (url) => {
          setLoading(true);
          setImageUrl(url);
        });
      }
    };

    const uploadButton = (
      <div>
        {loading ? <LoadingOutlined /> : <PlusOutlined />}
        <div
          style={{ marginTop: 8}}>
          Upload
        </div>
      </div>
    )
  let navigate = useNavigate();
  const CheckboxGroup = Checkbox.Group;
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [checkedList, setCheckedList] = useState("Male")
//   chcekbox male and female

const onChange = (e) => {
  console.log('radio checked', e.target.value);
  setCheckedList(e.target.value);
};
  return (
    <div className="vh-100 skill-bg">
    <div className="row m-0 p-0 d-flex justify-content-center ">
      <div className="col-md-8 col-12">
        <div className="card card-shadow px-3    my-2">
      <div className="row ">
     
        <div className="col-md-12 col-12">
        <ProgressStep step={0} />
        <h5 className="">Profile Registration</h5>
          <div className="card my-2  p-3 ">
            <div className="row">
            <div className="col-md-6 col-12">
                <Form
                layout="vertical"
                  // onFinish={onFinish}
                  // onFinishFailed={onFinishFailed}
                  autoComplete="off"
                >
                 
                  <Form.Item className="mb-1" label="I am Mr/Ms   ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1" label="Father’s/Guardian’s Name   ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-2" label="Age   ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-0" label="Gender   ">
                  <Radio.Group className="mb-0" onChange={onChange} value={checkedList}>
                    <Radio value="Male">Male</Radio>
                    <Radio value="Female">Female</Radio>
                    <Radio value="Other">Female</Radio>
           
                    </Radio.Group>
                    </Form.Item>
                  <Form.Item className="mb-1" label="I am ">
                    <Select>
                      <Select.Option value="demo">School</Select.Option>
                      <Select.Option value="demo">student</Select.Option>
                      <Select.Option value="demo">College</Select.Option>
                      <Select.Option value="demo">Fresher</Select.Option>
                      <Select.Option value="demo">Working</Select.Option>
                      <Select.Option value="demo">Professional</Select.Option>
                     
                    </Select>
                  </Form.Item>
                  <Form.Item className="mb-1" label="Email  ">
                    <Input />
                  </Form.Item>
                
                

                  
                </Form>
              </div>
              <div className="col-md-6 col-12">
                <Form
                  // form={form}
                  layout="vertical"
                  // onFinish={onFinish}
                  // onFinishFailed={onFinishFailed}
                  autoComplete="off"
                >
                  
                  <Form.Item
                  className="mb-0 p-0 "

                  label="Profile Img"
                  
                  valuePropName="fileList"
                  getValueFromEvent={normFile}
                >
                  <Upload  className="float-end mb-0 p-0 h_100"  action="/upload.do" listType="picture-card">
                    <div >
                      <PlusOutlined />
                      <div
                        style={{
                          marginTop: 8,
                        }}
                      >
                        Profile Img
                      </div>
                    </div>
                  </Upload>
                  {/* <Upload
        name="avatar"
        listType="picture-circle"
        className="avatar-uploader"
        showUploadList={false}
        action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
        beforeUpload={beforeUpload}
        onChange={handleChange}
      >
        {imageUrl ? <img src={imageUrl} alt="avatar" style={{ width: '100%' }} /> : uploadButton}
      </Upload> */}
                </Form.Item>
                <div className="row">
                  <Form.Item className="mb-1 col-12 col-md-6" label="Address   ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1 col-12 col-md-6 " label="Area/location    ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1 col-12 col-md-6" label="City   ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1 col-12 col-md-6 " label="District  ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1 col-12 col-md-6" label="State    ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1 col-12 col-md-6 " label="Pin Code    ">
                    <Input />
                  </Form.Item>
                  <Form.Item className="mb-1" label="Mobile No  ">
                    <Space.Compact style={{ width: '100%'}}>
                    <Input  />
                    <Button type="primary">Otp</Button>
                    </Space.Compact>
                  </Form.Item>
                  
                  </div>
                 
                </Form>
                </div>
                <Checkbox  className='mb-3 my-1' >I agreed with the Terms & Conditions of www.skill.com (a unit of M/s Monchi Enterprise).</Checkbox>
                
          
              <div className="col-md-12 col-12 "> 
                  <Button   onClick={()=> navigate("/EmployerReg2")} className="float-end bg-primary text-white">Next</Button>
              </div>
            </div>
            </div>
        </div>
      </div>
    </div>
    </div>
    </div>
    </div>
  );
};
export default EmployeReg;
