import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Navbaar = () => {
  let navigate = useNavigate();
  return (
<div>
<nav class="navbar navbar-expand-lg  r skill-bg h-25 m-0 p-0" >
  <div class="container-fluid">
    <a class="navbar-brand text-white" href="#">Careehub</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <Link class="nav-link  text-white" to="/">Home</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link text-white" to="/EmployerDashboard">Dashboard</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link text-white" to="/Abouts">About Us</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link text-white" to="/JobSearch">Job Search</Link>
        </li>
        <li class="nav-item">
          <Link to="/EmployersProfile" class="nav-link text-white" >Profile</Link>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"/></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <Link to="/TermCondation" class="nav-link text-white" >TermCondation</Link>
        </li>
        <li class="nav-item">
          <Link to="/Signin" class="nav-link text-white" >SignIn</Link>
        </li>
        {/* <li class="nav-item">
          <Link to="/" class="nav-link text-white" >Logout</Link>
        </li> */}
      </ul>
      
    </div>
     <form class="d-flex">
        <input class="form-control me-2 h_32" type="search" placeholder="Search" aria-label="Search"/>
        <button class="btn btn-info h_32" type="submit">Search</button>
      </form>
      
  </div>
  
</nav>
      
    </div>
  );
}

export default Navbaar;
