import { PlusOutlined } from "@ant-design/icons";
import React, { useState } from "react";
import {
  Button,
  Cascader,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Slider,
  Switch,
  TreeSelect,
  Upload,
} from "antd";
import { useNavigate } from "react-router-dom";
import ProgressStep from "../Component/ProgressStep";
const { RangePicker } = DatePicker;
const { TextArea } = Input;
const normFile = (e) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e?.fileList;
};
const EmployeReg2 = () => {
  let navigate = useNavigate();

  const [selectedValue, setSelectedValue] = useState("");
  const [selectedValue2, setSelectedValue2] = useState("");

  const handleSelectChange = (value) => {
    setSelectedValue(value);
  };
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [value, setValue] = useState();
  const [value1, setValue1] = useState();
  const onChange = (newValue) => {
    console.log(newValue);
    setValue(newValue);
  };
  const onChanges = (newValue) => {
    console.log(newValue);
    setValue1(newValue);
  };
  const treeData = [
    {
      value: "Clinical ",
      title: "Clinical ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Diagnostic Labs ",
      title: "Diagnostic Labs ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Technique  ",
      title: "Technique ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Other  ",
      title: "Other  ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
  ];
  const treeData2 = [
    {
      value: "Internship ",
      title: "Internship ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Programs ",
      title: "Programs ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Course  ",
      title: "Course ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Jobs  ",
      title: "Jobs  ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
  ];
  return (
    <div className="vh-10 skill-bg">
      <div className="row m-0 p-0 d-flex justify-content-center ">
        <div className="col-md-8 col-12">
          <div className="card card-shadow  px-3    my-5">
            <div className="row ">
              <div className="col-md-12 col-12">
                <ProgressStep step={1} />
                <h5 className="p-2 mt-2 text-success ">
                  Profile Registration My Academic -
                  <span className="text-dark"> Step-2</span>{" "}
                </h5>
                <div className="card my-2 mt-1  p-3 ">
                  <Form
                    layout="vertical"
                    // onFinish={onFinish}
                    // onFinishFailed={onFinishFailed}
                    autoComplete="off"
                  >
                    <div className="row">
                      <div className="col-md-12 col-12">
                        <Form.Item
                          className="mb-1 fw-bold"
                          label="I AM A SCHOOL STUDENT "
                        >
                          <Select
                            onChange={handleSelectChange}
                            value={selectedValue}
                          >
                            <Select.Option value="">None</Select.Option>
                            <Select.Option value="demo">11</Select.Option>
                            <Select.Option value="demo">12</Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                      {selectedValue.length > 0 ? (
                        <>
                          <div className="col-md-4 col-12">
                            <Form.Item
                              className="mb-1"
                              label="Name of the School  "
                            >
                              <Input />
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="Country ">
                              <Select>
                                <Select.Option value="demo">
                                  Student
                                </Select.Option>
                                <Select.Option value="demo">11</Select.Option>
                                <Select.Option value="demo">12</Select.Option>
                              </Select>
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="State ">
                              <Select>
                                <Select.Option value="demo">
                                  Student
                                </Select.Option>
                                <Select.Option value="demo">11</Select.Option>
                                <Select.Option value="demo">12</Select.Option>
                              </Select>
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="District ">
                              <Input />
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="City ">
                              <Input />
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item
                              className="mb-1"
                              label="Pin code / Zip Code  "
                            >
                              <Input />
                            </Form.Item>
                          </div>
                        </>
                      ) : (
                        ""
                      )}
                      <div className="col-md-12 col-12">
                        <Form.Item
                          className="mb-1 fw-bold"
                          label="2.	MY STREAM  "
                        >
                          <Select>
                            <Select.Option value="demo">
                              MY STREAM
                            </Select.Option>
                            <Select.Option value="demo">
                              Medical Science,{" "}
                            </Select.Option>
                            <Select.Option value="demo">
                              Engineering
                            </Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                      <div className="col-md-12 col-12">
                        <Form.Item
                          className="mb-1 fw-bold"
                          label="3 (A) MY MEDICAL BACHELOR DEGREE   "
                        >
                          <Select>
                            <Select.Option value="demo">
                              MY MEDICAL BACHELOR DEGREE
                            </Select.Option>
                            <Select.Option value="demo">
                              Medical Science,{" "}
                            </Select.Option>
                            <Select.Option value="demo">
                              Engineering
                            </Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                      <div className="col-md-4 col-12">
                        <Form.Item
                          className="mb-1"
                          label="Completed / Pursuing   "
                        >
                          <Input />
                        </Form.Item>
                      </div>
                      <div className="col-md-4 col-12">
                        <Form.Item
                          className="mb-1 "
                          label=" Year of completed/pursuing   "
                        >
                          <DatePicker className="w-100" />
                        </Form.Item>
                      </div>
                      <div className="col-md-4 col-12">
                        <Form.Item className="mb-1 " label="Course - ">
                          <Select>
                            <Select.Option value="demo">Course -</Select.Option>
                            <Select.Option value="demo">
                              Medical Science,{" "}
                            </Select.Option>
                            <Select.Option value="demo">
                              Engineering
                            </Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                      <div className="col-md-12 col-12">
                        <Form.Item
                          className="mb-1 fw-bold"
                          label="(B) Any Other Bachelor Degree  "
                        >
                          <Select
                            onChange={(val) => setSelectedValue2(val)}
                            value={selectedValue2}
                          >
                            <Select.Option value="">None</Select.Option>
                            <Select.Option value="demo">
                              Medical Science,{" "}
                            </Select.Option>
                            <Select.Option value="demo">
                              Engineering
                            </Select.Option>
                          </Select>
                        </Form.Item>
                      </div>
                      {selectedValue2.length > 0 ? (
                        <>
                          <div className="col-md-4 col-12">
                            <Form.Item
                              className="mb-1"
                              label="Name of the School  "
                            >
                              <Input />
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="Country ">
                              <Select>
                                <Select.Option value="demo">
                                  Student
                                </Select.Option>
                                <Select.Option value="demo">11</Select.Option>
                                <Select.Option value="demo">12</Select.Option>
                              </Select>
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="State ">
                              <Select>
                                <Select.Option value="demo">
                                  Student
                                </Select.Option>
                                <Select.Option value="demo">11</Select.Option>
                                <Select.Option value="demo">12</Select.Option>
                              </Select>
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="District ">
                              <Input />
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item className="mb-1" label="City ">
                              <Input />
                            </Form.Item>
                          </div>
                          <div className="col-md-4 col-12">
                            <Form.Item
                              className="mb-1"
                              label="Pin code / Zip Code  "
                            >
                              <Input />
                            </Form.Item>
                          </div>
                        </>
                      ) : (
                        ""
                      )}
                    </div>
                    <div className="col-md-12 col-12 mt-1">
                    <Form.Item  className="fw-bold" label=" Other Certifications if any ">
                          <TextArea rows={2} />
                        </Form.Item>
                        </div>
                        <div className="col-md-12 col-12 m-0 ">
                        <Form.Item  className="fw-bold" label="Experience if any ">
                          <TextArea rows={2} />
                        </Form.Item>
                        </div>
                        
                  </Form>

                  {/* <div className="col-md-12 col-12 m-0">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item label=" Desired Qualifications and Experience">
                          <TextArea rows={2} />
                        </Form.Item>
                      </Form>
                    </div>
                    <p className="mb-2">Desired other formalities - </p>
                    <Checkbox onChange={() => ""}>
                      {" "}
                      Forwarding letter from the studying institute/university
                    </Checkbox>
                    <Checkbox onChange={() => ""}> Valid Visa</Checkbox>
                    <Checkbox onChange={() => ""}> Health insurance </Checkbox> */}
                  {/* <Checkbox onChange={onChange}>•	Any Other </Checkbox> */}
                  <div className="col-md-12 col-12 ">
                    <Button
                      onClick={() => navigate("/HomePage")}
                      className="float-end bg-primary text-white"
                    >
                      Submit
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default EmployeReg2;
