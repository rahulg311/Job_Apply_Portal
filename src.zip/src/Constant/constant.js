// export const BaseURL="http://localhost:8000/api/";
// export const BaseURL="http://localhost:8000/";
export const BaseURL="https://careehub.com/api/";


export const ApiEndPoint={
    signup:`${BaseURL}signup`,
    signin:`${BaseURL}signin`,
    getJobsList:`${BaseURL}getJobsList`,
    appliedJob:`${BaseURL}appliedJob`,
    getAppliedJobs:`${BaseURL}getAppliedJobs`, 
    EmployerSignup:`${BaseURL}EmployerSignup`,
    generateOTP:`${BaseURL}generateOTP`,
    verifyOTP:`${BaseURL}verifyOTP`,
    upload:`${BaseURL}upload`,
    addEducation:`${BaseURL}addEducation`,
    getIndustryList:`${BaseURL}getIndustryList`,
    EmployerSignup:`${BaseURL}EmployerSignup`,
    
    
    
    
    
    
    
}