import { PlusOutlined } from "@ant-design/icons";
import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Button,
  Cascader,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Slider,
  Switch,
  TreeSelect,
  Upload,
  Steps,
  Space,
} from "antd";
import { useNavigate } from "react-router-dom";
import ProgressStep from "../Component/ProgressStep";
import { ApiEndPoint } from "../Constant/constant";
import { InputOTP } from "antd-input-otp";
import { ToastContainer, toast } from "react-toastify";
import Valoidation from "../Component/Validation";
import { State, Country, City } from 'country-state-city'
const Step = Steps.Step;
const { RangePicker } = DatePicker;
const { TextArea } = Input;
// const normFile = (e) => {
//   if (Array.isArray(e)) {
//     return e;
//   }
//   return e?.fileList;
// };
const normFile = (e) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e?.fileList;
};
const EmployerRegisterSetp1 = () => {
  let navigate = useNavigate();
  const [form] = Form.useForm();
  const [verifyedMobile, setVerifyedMobile] = useState(false)
  console.log("verifyed otp ",verifyedMobile)
  const [fileList, setFileList] = useState({});
  const countries = Country.getAllCountries();
  const[state, setstate] = useState([])
  const[Citys, setCitys] = useState([])
  
  console.log("City----",Citys)
//  job details add

const [jobDetails, setjobDetails] = useState(
  {
    name:"",
    industryType:"",
    type:"",
    contactPerson:"",
    responsibilities:"",
    email:"",
    mobile:"",
    organization:"",
    benefits:"",
    location:"",
    country:"",
    state:"",
    city:" ",
    profileimg:"employer",

}
)
console.log("jobDetails",jobDetails)

// const [FormData, setFormData] = useState({
//     name:"",
//     industryType:"",
//     type:"",
//     contactPerson:"",
//     responsibilities:"",
//     email:"",
//     mobile:"",
//     organization:"",
//     benefits:"",
//     location:"",
//     country:"",
//     city:" "


// });
const [EmployerRegisterSetp1, setEmployerRegisterSetp1] = useState(false);
const [industryInsert, setindustryInsert]= useState([])


  // send opt gentreated  method
  const SendOtp = async () => {
    form.resetFields();
    try {
      const mobileno = {
        phone: FormData.mobile,
      };

      if (mobileno.phone) {
        const response = await axios.post(ApiEndPoint.generateOTP, mobileno).then((res)=>{
          toast.success("Successfully sent OTP");
          console.log("Successful OTP send", res.data);
  
          const modal = document.getElementById("exampleModal");
          if (modal) {
            modal.classList.add("show"); // Ensure the 'show' class is added to display the modal
            modal.style.display = "block";
          } else {
            console.error("Modal not found");
          }

        }).catch((error)=>{
          console.log("invalid mobile no" ,error.response.data)
          toast.error(error.response.data.error
            );
        })

        // Assuming toast is available globally or imported from a library
     
      } else {
        toast.error("Mobile number not provided");
        console.log("Mobile number not provided");
      }
    } catch (error) {
      console.error("Error sending OTP", error);
    }
  };
  const handleChange1: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
    // if (info.file.status === 'uploading') {
    //   setLoading(true);
    //   return;
    // }
    console.log("onChange------upload-",info.file.status)
    // if (info.file.status === 'done') {
    //   // Get this url from response in real world.
    //   getBase64(info.file.originFileObj as RcFile, (url) => {
    //     setLoading(false);
    //     setImageUrl(url);
    //   });
    // }
  };

  // CLOSE POPUP  MODEL OTP
  const hideModal = () => {
    console.log("click---");
    form.resetFields();
    const modal = document.getElementById("exampleModal");
    if (modal) {
      modal.classList.remove("show"); // Remove the 'show' class to hide the modal
      modal.style.display = "none"; // Set display property to 'none' to hide the modal
     
    } else {
      console.error("Modal not found");
    }
    // const modalEle = modalRef.current;
    // const bsModal = bootstrap.Modal.getInstance(modalEle);
    // bsModal.hide();
  };

  useEffect(() => {
    console.log("FormData------", FormData);
  }, [FormData]);

  //  industryInsert get app


  useEffect(()=>{

    data()
  },[])


  const data = async ()=> {
    await axios.get(ApiEndPoint.getIndustryList).then((res)=>{

      setindustryInsert(res.data)
      console.log("industryInsert",res.data)

    }).catch((err)=>{
      console.log("errr",err)

    })

  }

  //  opt varifaction api
  const handleFinish = async (values) => {
    const { otp } = values;
    console.log("otp------", values);
    if (!otp || otp.includes(undefined) || otp.includes(""))
      return form.setFields([
        {
          name: "otp",
          errors: ["OTP is invalid."],
        },
      ]);

    console.log(`OTP: ${otp.join("")}`);
    const gennratedOtp = otp;
    console.log("gennratedOtp", gennratedOtp);
    if (gennratedOtp.length != 4) {
      toast.error("Invaild Otp");

      return;
    }

    const otpData = {
      phone: FormData.mobile,
      otp: gennratedOtp.join(""),
    };
    const val = Valoidation(otpData);
    if (!val) {
      return;
    }

    await axios
      .post(ApiEndPoint.verifyOTP, otpData)
      .then((res) => {
        if (res) {
          setVerifyedMobile(true)
          hideModal();
          form.resetFields();
          console.log("Successfully verify OTP");
          toast.success("Successfully verify OTP");
        }
      })
      .catch((error) => {
        toast.error("Does not verify OTP");

        console.log("Does not verify OTP", error);
      });
  };
  
  const navigateNextPage = async () => {

    axios.post(ApiEndPoint.EmployerSignup,jobDetails)
    .then(async (response) => {
      console.log("POST Request Response:", response.data);
      await sessionStorage.setItem("token", response?.data?.token);
      toast.success("setp 1 complate");
      navigate("/EmployerRegisterSetp2");
    }).catch((error) => {
      toast.error(error.response.data.message)
      console.error("Error making POST request:", error.response.data.message);
    });


    // EmployerSignup
    
    console.log("clik");

    // const postData = {
    //   title: "foo",
    //   body: "bar",
    //   userId: 1,
    // };

    // axios
    //   .post(ApiEndPoint.signup, postData)
    //   .then((response) => {
    //     console.log("POST Request Response:", response.data);
    //   })
    //   .catch((error) => {
    //     console.error("Error making POST request:", error);
    //   });
    // 👇️ navigate to /
   
  };




  return (
    <div className="vh-100 skill-bg">
          <ToastContainer />
      <div className="row m-0 p-0 d-flex justify-content-center ">
        <div className="col-md-8 col-12">
          <div className="card card-shadow my-3 px-3    my-5">
            <div className="row my-2">
              <div className="col-md-12 col-12">
                <ProgressStep step={0} />
                <h5 className="">Profile Registration</h5>
                <div className="card my-2  p-2 ">
                  <div className="row">
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                                          <Form.Item className="mb-1" label="Industry - Health">
                        <Select onChange={(val) => setjobDetails({ ...jobDetails, industryType: val })}>
                          {industryInsert.map((i) => (
                            <Select.Option key={i.name} value={i.name}>
                              {i.name}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                        <Form.Item className="mb-1" label="Name  ">
                        <Input  onChange={(e)=>{setjobDetails({...jobDetails, name: e.target.value})}}
                               value={jobDetails.name} />
                        </Form.Item>
                        {/* <Form.Item className="mb-1" label="Phone No  ">
                          <Input />
                        </Form.Item> */}
                        <Form.Item className="mb-1" label="Mobile No  ">
                            <Space.Compact style={{ width: "100%" }}>
                              <Input
                                maxLength={10}
                                type="mobile"
                                onChange={(val) =>
                                  setjobDetails({
                                    ...jobDetails,
                                    mobile: val.target.value,
                                  })
                                }
                              />
                              {
                                verifyedMobile != true ?
                              
                              <Button type="primary" onClick={SendOtp}>
                                Send Otp
                              </Button>
                              :
                              <Button type="primary">
                                Verifyed otp
                              </Button>
                              }
       
                            </Space.Compact>
                          </Form.Item>

                          {/* verifyedMobile */}

                    
                        <Form.Item className="mb-1" label="state">
                        <Select    onChange={(val)=>{
                           let str = val.split(" ");
                                  console.log("str------", str)
                                 let cityss = City.getCitiesOfState(str[1], str[0]);           
                                 setCitys(cityss)
                                setjobDetails({...jobDetails,state:val })
                                // setstate(State.getStatesOfCountry(val))
                                // setjobDetails({...jobDetails,country:val })}}
                        }}
                               value={jobDetails.state}>
                              
                             { state&& state.map((i,key)=>(
                              <Select.Option key={i.isoCode} value={`${i.isoCode} ${i.countryCode}`}>
                                {i.name}
                              </Select.Option>
                            ))} </Select>
                        </Form.Item>

                        <Form.Item className="mb-1" label="organization  ">
                          <Select  onChange={(val)=>{setjobDetails({...jobDetails, organization:val})}}
                               value={jobDetails.organization}>
                            <Select.Option value="">Demo</Select.Option>
                            <Select.Option value="Institute 1">Institute 1</Select.Option>
                            <Select.Option value="Institute 2">Institute 2</Select.Option>
                          </Select>
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-1"
                          label="Name of the contact person/HR  "
                        >
                          <Input  onChange={(e)=>{setjobDetails({...jobDetails, contactPerson: e.target.value})}}
                               value={jobDetails.contactPerson} />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Email  ">
                        <Input  onChange={(e)=>{setjobDetails({...jobDetails, email: e.target.value})}}
                               value={jobDetails.email} />
                        </Form.Item>

                        <Form.Item className="mb-1" label="Country">
                        <Select    onChange={(val)=>{
                                setstate(State.getStatesOfCountry(val))
                                setjobDetails({...jobDetails,country:val })}}
                               value={jobDetails.country}>
                              
                               {countries.map((i) => (
                              <Select.Option key={i.isoCode} value={i.isoCode}>
                                {i.name}
                              </Select.Option>
                            ))} </Select>
                        </Form.Item>
                       
                        <Form.Item className="mb-1" label="City ">
                        <Select onChange={(val)=>{setjobDetails({...jobDetails, city:val} )}
                               } value={jobDetails.city} >
                             {
                              Citys && Citys.map((i)=>(
                                <Select.Option   value={i.name} >{i.name}</Select.Option>
                              ))
                             }
                            

                              
                              </Select>
                            
                        </Form.Item>



                        <Form.Item className="mb-1" label="Location  ">
                        <Input  onChange={(e)=>{setjobDetails({...jobDetails, location: e.target.value})}}
                               value={jobDetails.location} />
                        </Form.Item>
                        <Form.Item
                          className="mb-1"
                          label="Web link of the organization  "
                        >
                              <Input  onChange={(e)=>{setjobDetails({...jobDetails, organization: e.target.value})}}
                               value={jobDetails.organization} />
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-0 p-0 "
                          label="Profile"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                        >
                            <Upload
                            className="float-end mb-0 p-0 h_100"
                            action={`${ApiEndPoint.upload}`}
                            // action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                            listType="picture-card"
                            // onChange={(fileList)=>{console.log("setFileList-----",fileList);setFileList(fileList.file.originFileObj)}}
                            // onChange={({ fileList }) => setFileList(fileList.slice(-1))}
                            onChange={handleChange1}
                            // onRemove={}
                            
                          >
                          
                           
                            {  Object.keys(fileList).length === 0 ? (
                            <div>
                            <PlusOutlined />
                            <div style={{ marginTop: 8 }}>Upload</div>
                            </div>
                            ) :null  }
                          </Upload>
                        </Form.Item>
                        <Form.Item className="mb-1" label="Responsibilities">
                        <Input  onChange={(e)=>{setjobDetails({...jobDetails, responsibilities: e.target.value})}}
                               value={jobDetails.responsibilities} />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Benefits for employ">
                        <Input  onChange={(e)=>{setjobDetails({...jobDetails, benefits: e.target.value})}}
                               value={jobDetails.benefits} />
                        </Form.Item>{" "}
                      </Form>
                    </div>

                    <div className="col-md-12 col-12">
                      <Button
                        onClick={navigateNextPage}
                        className="float-end bg-primary text-white"
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
          {/* <!-- Modal --> */}
          <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                {" "}
                Verify OTP
              </h5>
              <button
                type="button"
                class="btn-close"
                onClick={() => hideModal()}
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <Form form={form} onFinish={handleFinish}>
                <Form.Item
                  name="otp"
                  id="otpInput"
                  className="center-error-message"
                  rules={[{ validator: async () => Promise.resolve() }]}
                >
                  <InputOTP autoFocus inputType="numeric" length={4} />
                </Form.Item>

                <Form.Item noStyle>
                  <Button
                    className="mt-4"
                    block
                    htmlType="submit"
                    type="primary"
                  >
                    Submit Otp
                  </Button>
                </Form.Item>
              </Form>
            </div>
            {/* <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary fs_12"
                onClick={() => hideModal()}
              >
                Close
              </button>
              <button type="button"  class="btn btn-primary fs_12">
                Save changes
              </button>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};
export default EmployerRegisterSetp1;
