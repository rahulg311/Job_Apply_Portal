import { PlusOutlined } from "@ant-design/icons";
import React, { useState } from "react";
import {
  Button,
  Cascader,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Slider,
  Switch,
  TreeSelect,
  Upload,
} from "antd";
import { useNavigate } from "react-router-dom";
import ProgressStep from "../Component/ProgressStep";

const { RangePicker } = DatePicker;
const { TextArea } = Input;
const normFile = (e) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e?.fileList;
};
const EmployerRegisterSetp2 = () => {
  let navigate = useNavigate();
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [value, setValue] = useState();
  const [value1, setValue1] = useState();
  const onChange = (newValue) => {
    console.log(newValue);
    setValue(newValue);
  };
  const onChanges = (newValue) => {
    console.log(newValue);
    setValue1(newValue);
  };
  const treeData = [
    {
      value: "Clinical ",
      title: "Clinical ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Diagnostic Labs ",
      title: "Diagnostic Labs ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Technique  ",
      title: "Technique ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Other  ",
      title: "Other  ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
  ];
  const treeData2 = [
    {
      value: "Internship ",
      title: "Internship ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Programs ",
      title: "Programs ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Course  ",
      title: "Course ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
    {
      value: "Jobs  ",
      title: "Jobs  ",
      children: [
        {
          value: "leaf1",
          title: "my leaf",
        },
        {
          value: "leaf2",
          title: "your leaf",
        },
      ],
    },
  ];




  return (
    <div className="vh-10 skill-bg">
      <div className="row m-0 p-0 d-flex justify-content-center ">
        <div className="col-md-9 col-12">
          <div className="card  card-shadow px-3    my-2">
            <div className="row ">
              <div className="col-md-12 col-12">
                <ProgressStep step={1} />
                <h5 className="p-2 mt-2 text-success ">
                Job Description -
                  <span className="text-dark"> Step-2</span>{" "}
                </h5>
                <div className="card my-2 mt-1  p-3 ">
                  <div className="row">
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-1"
                          label="Select the departments  "
                        >
                          <TreeSelect
                            showSearch
                            style={{
                              width: "100%",
                            }}
                            value={value}
                            dropdownStyle={{
                              maxHeight: 400,
                              overflow: "auto",
                            }}
                            placeholder="Please select"
                            allowClear
                            // multiple
                            // treeDefaultExpandAll
                            onChange={onChange}
                            treeData={treeData}
                          />
                        </Form.Item>
                        <Form.Item
                          className="mb-1"
                          label="Name of the Department   "
                        >
                          <Input value={value} />
                        </Form.Item>

                        {/* <Form.Item className="mb-1" label="Role / Openings ">
                    <Select>
                      <Select.Option value="demo">Demo</Select.Option>
                      <Select.Option value="demo">1</Select.Option>
                      <Select.Option value="demo">2</Select.Option>
                    </Select>
                  </Form.Item> */}
                        <Form.Item
                          className="mb-1"
                          label="Number of Seats / Opening   "
                        >
                          <Input />
                        </Form.Item>

                        <Form.Item className="" label="Certification Issuing ">
                          <Radio.Group>
                            <Radio value="Yes"> Yes </Radio>
                            <Radio value="No"> No</Radio>
                          </Radio.Group>
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-1"
                          label="Role / Openings for "
                        >
                          <TreeSelect
                            showSearch
                            style={{
                              width: "100%",
                            }}
                            value={value1}
                            dropdownStyle={{
                              maxHeight: 400,
                              overflow: "auto",
                            }}
                            placeholder="Please select"
                            allowClear
                            // multiple
                            // treeDefaultExpandAll
                            onChange={onChanges}
                            treeData={treeData2}
                          />
                        </Form.Item>
                        <Form.Item className="mb-1" label=" Fee  ">
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>
                        <Form.Item className="mb-1" label="If Paid (Amount)">
                          <Input />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Stipend – Rs ">
                          <Select>
                            <Select.Option value="demo">Demo</Select.Option>
                            <Select.Option value="demo">1</Select.Option>
                            <Select.Option value="demo">2</Select.Option>
                          </Select>
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-4 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                             <Form.Item
                          className="mb-0 p-0 "
                          label=" Job Profile"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                        >
                          <Upload
                            className="float-end mb-0 p-0 h_100"
                            action="/upload.do"
                            listType="picture-card"
                            showUploadList="none"
                          >
                            <div>
                              <PlusOutlined />
                              <div
                                style={{
                                  marginTop: 8,
                                }}
                              >
                                Upload
                              </div>
                            </div>
                          </Upload>
                        </Form.Item>
               
                        <Form.Item className="mb-1 w-100" label="Date of Opening">
                          <DatePicker className=" w-100" />
                        </Form.Item>
                        <Form.Item className="mb-1" label="Language ">
                          <Select>
                            <Select.Option value="demo"> Choose Language</Select.Option>
                            <Select.Option value="0">Germany</Select.Option>
                            <Select.Option value="1">English</Select.Option>
                            <Select.Option value="2">Spanish</Select.Option>
                          </Select>
                        </Form.Item>
                        {/* <Form.Item className="mb-1" label="If Paid (Amount)">
                    <Input />
                  </Form.Item> */}
                        
                      </Form>
                    </div>
                    <div className="col-md-12 col-12 m-0">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item label=" Desired Qualifications and Experience">
                          <TextArea rows={2} />
                        </Form.Item>
                      </Form>
                    </div>
                    <p className="mb-2">Desired other formalities - </p>
                    <Checkbox onChange={() => ""}>
                      {" "}
                      Forwarding letter from the studying institute/university
                    </Checkbox>
                    <Checkbox onChange={() => ""}> Valid Visa</Checkbox>
                    <Checkbox onChange={() => ""}> Health insurance </Checkbox>
                    {/* <Checkbox onChange={onChange}>•	Any Other </Checkbox> */}
                    <div className="col-md-12 col-12 ">
                      <Button
                        onClick={() => navigate("/EmployerDashboard")}
                        className="float-end bg-primary text-white"
                      >
                        Submit
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default EmployerRegisterSetp2;
