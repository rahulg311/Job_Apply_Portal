import { PlusOutlined, LoadingOutlined } from "@ant-design/icons";
import React, { useEffect, useState } from "react";
import {
  message,
  Button,
  Cascader,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Slider,
  Switch,
  TreeSelect,
  Upload,
  Steps,
  Space,
} from "antd";
import { useNavigate } from "react-router-dom";
import ProgressStep from "../Component/ProgressStep";
import { ApiEndPoint } from "../Constant/constant";
import axios from "axios";
import Valoidation from "../Component/Validation";
import { ToastContainer, toast } from "react-toastify";
// import { Button, Form } from 'antd';
import { InputOTP } from "antd-input-otp";
//  profile pic uploade 1
const normFile = (e) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e?.fileList;
};

//  profile pic uploade 2
const getBase64 = (img, callback) => {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result));
  reader.readAsDataURL(img);
};
const beforeUpload = (file) => {
  const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
  if (!isJpgOrPng) {
    message.error("You can only upload JPG/PNG file!");
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error("Image must smaller than 2MB!");
  }
  return isJpgOrPng && isLt2M;
};

const EmployeReg = () => {
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState();
  const [verifyedMobile, setVerifyedMobile] = useState(false)
  const [form] = Form.useForm();
  const handleChange = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    if (info.file.status === "done") {
      // Get this url from response in real world.
      getBase64(info.file.originFileObj, (url) => {
        setLoading(true);
        setImageUrl(url);
      });
    }
  };

  const uploadButton = (
    <div>
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );
  let navigate = useNavigate();
  const CheckboxGroup = Checkbox.Group;
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [checkedList, setCheckedList] = useState("male");
  const [otpVerify, setOtpVerify] = useState("");
  const [fileList, setFileList] = useState({});
  const [FormData, setFormData] = useState({
    address: "",
    age: "",
    city: "",
    district: "",
    email: "",
    fathername: "",
    gender: "",
    location: "",
    mobile: "",
    name: "",
    pincode: "",
    role: "",
  });
  console.log("otpVerify----", otpVerify);
  console.log("fileList----", fileList);


  

  const submit = () => {
    // navigate("/EmployerReg2");
    
    // const validations = Valoidation(FormData);
    // console.log("validations-----", validations);
    // if (!validations) {
    //   return;
    // } 
    // if (verifyedMobile != true) {
    //   toast.error("Please verify mobile no");

    //   return;
    // }
    axios.post(ApiEndPoint.signup, FormData)
      .then(async (response) => {
        console.log("POST Request Response:", response.data);
        await sessionStorage.setItem("token", response?.data?.token);
        toast.success("setp 1 complate");
        navigate("/EmployerReg2");
      }).catch((error) => {
        toast.error(error.response.data.message)
        console.error("Error making POST request:", error.response.data.message);
      });
  };

  // send opt gentreated  method
  const SendOtp = async () => {
    form.resetFields();
    try {
      const mobileno = {
        phone: FormData.mobile,
      };

      if (mobileno.phone) {
        const response = await axios.post(ApiEndPoint.generateOTP, mobileno).then((res)=>{
          toast.success("Successfully sent OTP");
          console.log("Successful OTP send", res.data);
  
          const modal = document.getElementById("exampleModal");
          if (modal) {
            modal.classList.add("show"); // Ensure the 'show' class is added to display the modal
            modal.style.display = "block";
          } else {
            console.error("Modal not found");
          }

        }).catch((error)=>{
          console.log("invalid mobile no" ,error.response.data)
          toast.error(error.response.data.error
            );
        })

        // Assuming toast is available globally or imported from a library
     
      } else {
        toast.error("Mobile number not provided");
        console.log("Mobile number not provided");
      }
    } catch (error) {
      console.error("Error sending OTP", error);
    }
  };

  // CLOSE POPUP  MODEL OTP
  const hideModal = () => {
    console.log("click---");
    form.resetFields();
    const modal = document.getElementById("exampleModal");
    if (modal) {
      modal.classList.remove("show"); // Remove the 'show' class to hide the modal
      modal.style.display = "none"; // Set display property to 'none' to hide the modal
      setOtpVerify("");
    } else {
      console.error("Modal not found");
    }
    // const modalEle = modalRef.current;
    // const bsModal = bootstrap.Modal.getInstance(modalEle);
    // bsModal.hide();
  };

  useEffect(() => {
    console.log("FormData------", FormData);
  }, [FormData]);

  //  profile image uplode
  const UploadImage =async () => {
    // if(fileList){
      const formData = new window.FormData()
      formData.append('file', fileList);
      console.log("fileList--------------",fileList)
      try {
        await axios.post(ApiEndPoint.upload ,formData,{
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }).then((res)=>{
          console.log("upload profile image",res)
        })
        
        
      } catch (error) {
        console.log("not upload profile image")
        
      }
    // }else{
    //   console.log("profile image not uplode")


    // }
   
    // Update the fileList in the state
    setFileList(fileList);
  };

  //  opt varifaction api
  const handleFinish = async (values) => {
    const { otp } = values;
    console.log("otp------", values);
    if (!otp || otp.includes(undefined) || otp.includes(""))
      return form.setFields([
        {
          name: "otp",
          errors: ["OTP is invalid."],
        },
      ]);

    console.log(`OTP: ${otp.join("")}`);
    const gennratedOtp = otp;
    console.log("gennratedOtp", gennratedOtp);
    if (gennratedOtp.length != 4) {
      toast.error("Invaild Otp");

      return;
    }

    const otpData = {
      phone: FormData.mobile,
      otp: gennratedOtp.join(""),
    };
    const val = Valoidation(otpData);
    if (!val) {
      return;
    }

    await axios
      .post(ApiEndPoint.verifyOTP, otpData)
      .then((res) => {
        if (res) {
          setVerifyedMobile(true)
          hideModal();
          form.resetFields();
          console.log("Successfully verify OTP");
          toast.success("Successfully verify OTP");
        }
      })
      .catch((error) => {
        toast.error("Does not verify OTP");

        console.log("Does not verify OTP", error);
      });
  };

  const handleChange1: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
    // if (info.file.status === 'uploading') {
    //   setLoading(true);
    //   return;
    // }
    console.log("onChange------upload-",info.file.status)
    // if (info.file.status === 'done') {
    //   // Get this url from response in real world.
    //   getBase64(info.file.originFileObj as RcFile, (url) => {
    //     setLoading(false);
    //     setImageUrl(url);
    //   });
    // }
  };

  return (
    <div className="vh-100 skill-bg w-100 ">
      <ToastContainer />

      <div className="row m-0 p-0 d-flex justify-content-center ">
        <div className="col-md-8 col-12">
          <div className="card card-shadow px-3    my-2">
            <div className="row ">
              <div className="col-md-12 col-12">
                <ToastContainer />
                <ProgressStep step={0} />
                <h5 className="">Profile Registration</h5>
                <div className="card my-2  p-3 ">
                  <div className="row">
                    <div className="col-md-6 col-12">
                      <Form
                        layout="vertical"
                        // onFinish={onFinish}f
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item className="mb-1" label="I am Mr/Ms   ">
                          <Input
                            onChange={(val) =>
                              setFormData({
                                ...FormData,
                                name: val.target.value,
                              })
                            }
                          />
                        </Form.Item>
                        <Form.Item
                          className="mb-1"
                          label="Father’s/Guardian’s Name   "
                        >
                          <Input
                            onChange={(val) =>
                              setFormData({
                                ...FormData,
                                fathername: val.target.value,
                              })
                            }
                          />
                        </Form.Item>
                        <Form.Item className="mb-2" label="Age   ">
                          <Input
                            onChange={(val) =>
                              setFormData({
                                ...FormData,
                                age: val.target.value,
                              })
                            }
                          />
                        </Form.Item>
                        <Form.Item className="mb-0" label="Gender   ">
                          <Radio.Group
                            className="mb-0"
                            onChange={(val) =>
                              setFormData({
                                ...FormData,
                                gender: val.target.value,
                              })
                            }
                            value={FormData?.gender}
                          >
                            <Radio value="male">Male</Radio>
                            <Radio value="female">Female</Radio>
                            {/* <Radio value="Other">Female</Radio> */}
                          </Radio.Group>
                        </Form.Item>
                        <Form.Item className="mb-1" label="I am ">
                          <Select
                            onChange={(val) => {
                              setFormData({ ...FormData, role: val });
                              console.log("test----", val);
                            }}
                            value={FormData?.role}
                          >
                            <Select.Option value="demo1">School</Select.Option>
                            <Select.Option value="demo2">student</Select.Option>
                            <Select.Option value="demo3">College</Select.Option>
                            <Select.Option value="demo4">Fresher</Select.Option>
                            <Select.Option value="demo5">Working</Select.Option>
                            <Select.Option value="demo6">
                              Professional
                            </Select.Option>
                          </Select>
                        </Form.Item>
                        <Form.Item className="mb-1" label="Email  ">
                          <Input
                            onChange={(val) =>
                              setFormData({
                                ...FormData,
                                email: val.target.value,
                              })
                            }
                          />
                        </Form.Item>
                      </Form>
                    </div>
                    <div className="col-md-6 col-12">
                      <Form
                        // form={form}
                        layout="vertical"
                        // onFinish={onFinish}
                        // onFinishFailed={onFinishFailed}
                        autoComplete="off"
                      >
                        <Form.Item
                          className="mb-0 p-0 "
                          label="Profile Img"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                        >
                          <Upload
                            className="float-end mb-0 p-0 h_100"
                            action={`${ApiEndPoint.upload}`}
                            // action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                            listType="picture-card"
                            // onChange={(fileList)=>{console.log("setFileList-----",fileList);setFileList(fileList.file.originFileObj)}}
                            // onChange={({ fileList }) => setFileList(fileList.slice(-1))}
                            onChange={handleChange1}
                            // onRemove={}
                            
                          >
                          
                           
                            {  Object.keys(fileList).length === 0 ? (
                            <div>
                            <PlusOutlined />
                            <div style={{ marginTop: 8 }}>Upload</div>
                            </div>
                            ) :null  }
                          </Upload>
                          {/* <button  onClick={UploadImage}>submit</button> */}
                     
                        </Form.Item>
                        <div className="row">
                          <Form.Item
                            className="mb-1 col-12 col-md-6"
                            label="Address   "
                          >
                            <Input
                              onChange={(val) =>
                                setFormData({
                                  ...FormData,
                                  address: val.target.value,
                                })
                              }
                            />
                          </Form.Item>
                          <Form.Item
                            className="mb-1 col-12 col-md-6 "
                            label="Area/location    "
                          >
                            <Input
                              onChange={(val) =>
                                setFormData({
                                  ...FormData,
                                  location: val.target.value,
                                })
                              }
                            />
                          </Form.Item>
                          <Form.Item
                            className="mb-1 col-12 col-md-6"
                            label="City   "
                          >
                            <Input
                              onChange={(val) =>
                                setFormData({
                                  ...FormData,
                                  city: val.target.value,
                                })
                              }
                            />
                          </Form.Item>
                          <Form.Item
                            className="mb-1 col-12 col-md-6 "
                            label="District  "
                          >
                            <Input
                              onChange={(val) =>
                                setFormData({
                                  ...FormData,
                                  district: val.target.value,
                                })
                              }
                            />
                          </Form.Item>
                          <Form.Item
                            className="mb-1 col-12 col-md-6"
                            label="State    "
                          >
                            <Input
                              onChange={(val) =>
                                setFormData({
                                  ...FormData,
                                  state: val.target.value,
                                })
                              }
                            />
                          </Form.Item>
                          <Form.Item
                            className="mb-1 col-12 col-md-6 "
                            label="Pin Code    "
                          >
                            <Input
                              onChange={(val) =>
                                setFormData({
                                  ...FormData,
                                  pincode: val.target.value,
                                })
                              }
                            />
                          </Form.Item>
                          <Form.Item className="mb-1" label="Mobile No  ">
                            <Space.Compact style={{ width: "100%" }}>
                              <Input
                                maxLength={10}
                                type="mobile"
                                onChange={(val) =>
                                  setFormData({
                                    ...FormData,
                                    mobile: val.target.value,
                                  })
                                }
                              />
                              {
                                verifyedMobile != true ?
                              
                              <Button type="primary" onClick={SendOtp}>
                                Send Otp
                              </Button>
                              :
                              <Button type="primary">
                                Verifyed otp
                              </Button>
                              }
                            </Space.Compact>
                          </Form.Item>
                        </div>
                      </Form>
                    </div>
                    <Checkbox className="mb-3 my-1">
                      I agreed with the Terms & Conditions of www.careehub.com
                      (a unit of M/s Monchi Enterprise).
                    </Checkbox>

                    <div className="col-md-12 col-12 ">
                      <Button
                        onClick={submit}
                        className="float-end bg-primary text-white "
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Modal --> */}
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">
                {" "}
                Verify OTP
              </h5>
              <button
                type="button"
                class="btn-close"
                onClick={() => hideModal()}
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <Form form={form} onFinish={handleFinish}>
                <Form.Item
                  name="otp"
                  id="otpInput"
                  className="center-error-message"
                  rules={[{ validator: async () => Promise.resolve() }]}
                >
                  <InputOTP autoFocus inputType="numeric" length={4} />
                </Form.Item>

                <Form.Item noStyle>
                  <Button
                    className="mt-4"
                    block
                    htmlType="submit"
                    type="primary"
                  >
                    Submit Otp
                  </Button>
                </Form.Item>
              </Form>
            </div>
            {/* <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary fs_12"
                onClick={() => hideModal()}
              >
                Close
              </button>
              <button type="button"  class="btn btn-primary fs_12">
                Save changes
              </button>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};
export default EmployeReg;
