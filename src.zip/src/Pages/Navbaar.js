import { Image } from "antd";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
import { faUser } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { ToastContainer, toast } from "react-toastify";

const Navbaar = () => {
  let navigate = useNavigate();
  const [isLogin, setLogin] = useState(false);
  useEffect(() => {
    getToken();
  });

  async function getToken() {
    let token = await sessionStorage.getItem("loginToken");
    console.log("token-----", token);
    if (token) {
      setLogin(true);
    }
  }
  const Logout = () => {
    sessionStorage.clear();
    toast.warning("seuccefull Logout");
    navigate("/");
  };

  return (
    <div>
      <nav class="navbar navbar-expand-lg  r skill-bg h-25 m-0 p-0">
        <ToastContainer />
        <div class="container-fluid">
          <a class="navbar-brand text-white" href="/">
            <Image
              // width={"50%"}
              height={"45px"}
              preview={false}
              // className={"slider-height2 d-flex align-items-center"}
              src={require("../images/Website Logos.png")}
            />
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              {/* <li class="nav-item">
          <Link class="nav-link  text-white" to="/">Home</Link>
        </li> */}
              {isLogin && (
                <li class="nav-item">
                  <Link class="nav-link text-white" to="/EmployerDashboard">
                    Dashboard
                  </Link>
                </li>
              )}
              <li class="nav-item">
                <Link class="nav-link text-white" to="/Abouts">
                  About Us
                </Link>
              </li>
              <li class="nav-item">
                <Link class="nav-link text-white" to="/JobSearch">
                  Job Search
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/EmployersProfile" class="nav-link text-white">
                  Profile
                </Link>
              </li>
              <li class="nav-item dropdown">
                <a
                  class="nav-link dropdown-toggle text-white"
                  href="#"
                  id="navbarDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Trend
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li>
                    <a class="dropdown-item" href="/JobSearch">
                      Clinical
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="/JobSearch">
                      Hospital
                    </a>
                  </li>
                  <li>
                    <hr class="dropdown-divider" />
                  </li>
                  <li>
                    <a class="dropdown-item" href="#">
                      Something else here
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <Link to="/TermCondation" class="nav-link text-white">
                  TermCondation
                </Link>
              </li>
              {!isLogin && (
                <li class="nav-item">
                  <Link to="/Login" class="nav-link text-white">
                    SignIn
                  </Link>
                </li>
              )}

              {/* <li class="nav-item">
          <Link to="/" class="nav-link text-white" >Logout</Link>
        </li> */}
            </ul>
          </div>
          {/* <form class="d-flex "> */}
          {/* <div className=''> */}
          {isLogin && (
            <>
          <div className="d-flex">
            <FontAwesomeIcon className="ms-4 mt-1 fs_13" icon={faUser} />
            <p className="text-white ms-2 fs_13">Rahul gupta</p>
            {/* {capitalizeFirstLetter(UserDetails)} */}
          </div>
          <button
            className="ms-2 btn btn-primary  fs_12 "
            onClick={() => Logout()}
          >
            <FontAwesomeIcon icon={faSignOutAlt} />
            <span className="fw-none ms-1 mt-3">Logout</span>
          </button>
          </>
          ) }
        </div>
   
         
        {/* <input class="form-control me-2 h_32" type="search" placeholder="Search" aria-label="Search"/>
        <button class="btn btn-info h_32" type="submit">Search</button> */}
        {/* </form> */}

        {/* </div> */}
      </nav>
    </div>
  );
};

export default Navbaar;
