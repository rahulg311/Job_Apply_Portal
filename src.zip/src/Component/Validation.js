import React from 'react';
import { toast } from "react-toastify";

const Valoidation = (data) => {
  for (let key in data) {
    if (data.hasOwnProperty(key) && data[key] === "") {
      toast.error(`plese insert ${key} `);
      return false;
    }
  }

  return true;
};

export default Valoidation;
