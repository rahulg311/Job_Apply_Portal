import React from 'react'

function UserToken() {
    const UserToken = sessionStorage.getItem("loginToken");
  return UserToken
}

export default UserToken
