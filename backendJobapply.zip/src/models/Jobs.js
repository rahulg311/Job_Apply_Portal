const mongoose = require('mongoose');

const jobsSchema = new mongoose.Schema({

    user: { 
        type: mongoose.Schema.Types.ObjectId, 
        required: true, 
        ref: 'user'
    },
    openingType:{ 
        type: String, 
        required: true, 
        min: 3,     
        max: 50
     },
     nameDepartments: { 
        type: String, 
        required: true,
        trim: true 
     },
     opening: { 
        type: Number, 
        required: true,
        trim: true 
     },
     feeType: { 
        type: String, 
        required: true,
        trim: true 
     },
     date: { 
        type: String, 
        required: true,
        trim: true
     },
     certification: { 
        type: String, 
        required: true,
        trim: true 
     },
     stipend: { 
        type: Number, 
        trim: true 
     },
     description: { 
        type: String, 
        required: true,
        min: 10,
        max: 100
    }
},{timestamps: true });

// const applicantEducationSchema = new mongoose.Schema({
//     user: { 
//         type: mongoose.Schema.Types.ObjectId, 
//         required: true, 
//         ref: 'User'
//     },
//     education : [educationSchema],
    
// },{timestamps: true });
module.exports = mongoose.model('JobsList', jobsSchema);
    