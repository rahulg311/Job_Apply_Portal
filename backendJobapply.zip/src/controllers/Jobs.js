const Jobs = require("../models/Jobs");

exports.addJobs = (req, res) => {
  const { payload } = req.body;
  if (payload.jobs) {
    const {
      openingType,
      nameDepartments,
      opening,
      feeType,
      date,
      certification,
      stipend,
      description,
    } = payload.jobs;

    const newJob = new Jobs({
      user: req.user._id,
      openingType,
      nameDepartments,
      opening,
      feeType,
      date,
      certification,
      stipend,
      description,
    });

    newJob
      .save()
      .then((savedJob) => {
        if (savedJob) {
          res.status(200).json({ savedJob });
        }
      })
      .catch((error) => {
        if (error) return res.status(400).json({ error });
      });
  } else {
    res.status(400).json({ error: "params education required" });
  }
};

exports.getJobsList = (req, res) => {
    Jobs.find()
    .then((savedJob) => {
        if (savedJob) {
          res.status(200).json({ savedJob });
        }
      })
      .catch((error) => {
        if (error) return res.status(400).json({ error });
      });
}
