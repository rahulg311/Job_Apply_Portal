const User = require("../models/user");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const ShortUniqueId = require("short-unique-id");
const Employer = require("../models/Employer");
// const shortid = require('shortid');

exports.signup = (req, res) => {
  const uid = new ShortUniqueId();
  User.findOne({
    $or: [{ email: req.body.email }, { mobile: req.body.mobile }]
  }).then(async (data) => {
    console.log("tesat------", data);
    if (data) {
      return res.status(400).json({
        message: "User is already registered",
      });
    }

    const {
      name,
      fathername,
      age,
      gender,
      role,
      email,
      mobile,
      address,
      password,
      location,
      city,
      district,
      state,
      pincode,
    } = req.body;
    const hash_password = await bcrypt.hash(mobile, 10);
    const _user = new User({
      name,
      fathername,
      age,
      gender,
      role,
      email,
      address,
      location,
      city,
      district,
      state,
      pincode,
      hash_password,
      mobile,
      username: uid.stamp(32),
    });

    _user
      .save()
      .then((data) => {
        if (data) {
            const token = jwt.sign(
                { _id: data._id, type: data.type },
                process.env.JWT_SECRET,
                { expiresIn: "30d" }
              );
              console.log("data-----rw--",data)
          return res.status(200).json({
            message: "Registration  is successful.",token:token

          });
        }
      })
      .catch((error) => {
        if (error) {
          return res.status(400).json(error);
        }
      });
  });
};

exports.employerSignUp = (req, res) => {
  const uid = new ShortUniqueId();
  Employer.findOne({
    $or: [{ email: req.body.email }, { mobile: req.body.mobile }]
  }).then(async (data) => {
    console.log("tesat------", data);
    if (data) {
      return res.status(400).json({
        message: "User is already registered",
      });
    }

    const {
      industryType,
      name,
      contactPerson,
      type,
      responsibilities,
      email,
      mobile,
      organization,
      password,
      country,
      location,
      city,
      benefits

    } = req.body;
    const hash_password = await bcrypt.hash("TestPassword", 10);
    const _Employer = new Employer({
      industryType,
      name,
      contactPerson,
      type,
      responsibilities,
      email,
      mobile,
      organization,
      password,
      country,
      location,
      city,
      benefits,
      hash_password,
      username: uid.stamp(32),
    });

    _Employer
      .save()
      .then((data) => {
        if (data) {
            const token = jwt.sign(
                { _id: data._id, type: data.type },
                process.env.JWT_SECRET,
                { expiresIn: "1d" }
              );
              console.log("data-----rw--",data)
          return res.status(200).json({
            message: "Registration  is successful.",token:token
          });
        }
      })
      .catch((error) => {
        if (error) {
          return res.status(400).json({
            message: error
          });
        }
      });
  });
};


exports.signin = (req, res) => {
  let {role}=req.body;
  if(role=="employee"){
    User.findOne({ mobile: req.body.phone }).then(async (user) => {
      console.log("notEmpty----1",user)

      if (user) {
        console.log("notEmpty----2",user)
        if (user.authenticate(req.body.password)) {
          try {
            const admin = await bcrypt.compare(
              req.body.password,
              user.hash_password
            );
            if (admin) {
              const token = jwt.sign(
                { _id: user._id, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: "30d" }
              );
              // res.cookie("token", token);
              // const { firstname, lastname, role, email, fullname } = user;
  
              // storing token in client browser
              res.status(200).json({
                token,
                user: user
              });
            } else {
              res.status(400).json({
                message: "invalid password",
              });
            }
          } catch (e) {
            res.status(400).json({
              message: "server error",
            });
          }
        } else {
          return res.status(400).json({
            message: "invalid user",
          });
        }
      }
    }).catch((error) => {
      if (error) {
        return res.status(400).json({
          message: error
        });
      }
    });
  }else{
    Employer.findOne({ mobile: req.body.mobile }).then(async (error, user) => {
      if (user) {
        if (user.authenticate(req.body.password)) {
          try {
            const admin = await bcrypt.compare(
              req.body.password,
              user.hash_password
            );
            if (admin) {
              const token = jwt.sign(
                { _id: user._id, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: "30d" }
              );
              // res.cookie("token", token);
  
              // storing token in client browser
              res.status(200).json({
                token,
                user: user
              });
            } else {
              res.status(400).json({
                message: "invalid password",
              });
            }
          } catch (e) {
            res.status(400).json({
              message: "server error",
            });
          }
        } else {
          return res.status(400).json({
            message: "invalid user",
          });
        }
      }
    }).catch((error) => {
      if (error) {
        return res.status(400).json({
          message: error
        });
      }
    });
  }

};

// exports.signin = (req, res) => {

//     User.findOne({email: req.body.email})
//     .exec((error, user) => {
//         if(error) return res.status(400).json({ error })
//         if(user){

//             if(user.authenticate(req.body.password)){
//                 const token = jwt.sign({_id: user._id, role: user.role } , process.env.JWT_SECRET , { expiresIn: '1d'});
//                 const {firstname, lastname, role ,email ,fullname} =user;

//                 // storing token in client browser
//                 res.cookie("jwt",token,{
//                     // expires: new Date(Date.now() + 3600000*24*24),
//                     httpOnly: true
//                 });
//                 ////

//                 res.status(200).json({
//                     token,
//                     user: {
//                         firstname, lastname, role ,email ,fullname
//                     }
//                 });
//             }else{
//                 return res.status(400).json({
//                     message: "invalid user"
//                 })
//             }
//         }else{

//         }
//     })
// }
