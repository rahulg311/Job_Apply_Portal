const AppliedJob = require('../models/AppliedJob');
// const Cart = require('../models/cart')

function runUpdate(condition, updateData) {

    return new Promise((resolve, reject) => {

        AppliedJob.findOneAndUpdate(condition, updateData, { upsert: true })
            .then(result => resolve())
            .catch(err => reject(err))
    });
}

exports.AppliedJobs = async (req, res) => {

    const appliedJob = await AppliedJob.findOne({ user: req.user._id });
    if (appliedJob) {
        // res.status(201).json({appliedJob:"appliedJob part com"})
        // update appliedJob
        let promiseArray = [];
        let alreadyApplied=false
        req.body.applied.forEach((applied) => {
            const job = applied.job;
            const item = appliedJob.applied.find(c => c.job == job);
            let condition, update;
            if (item) {
                // condition = { "user": req.user._id, "applied.job": job };
                // update = {
                //     "$set": {
                //         "applied.$": applied
                //     }
                // };
                
                alreadyApplied=true;
            } else {
                condition = { user: req.user._id };
                update = {
                    "$push": {
                        "applied": applied
                    }
                };
            }
            if(Boolean(condition)){
                promiseArray.push(runUpdate(condition, update));
            } 
        });
        if(alreadyApplied){
            res.status(200).json({ message:"you have already applied" });
            return
        }else{
        Promise.all(promiseArray)
            .then(response => res.status(200).json({ response }))
            .catch(error => res.status(400).json({ error }));
        }
    } else {

        // create new cart if it's not exist
        const appliedJob = new AppliedJob({
            user: req.user._id,
            applied: [req.body.applied]
        });

        appliedJob.save()
        .then((savedJob) => {
            if (savedJob) {
              res.status(200).json({ savedJob });
            }
          })
          .catch((error) => {
            if (error) return res.status(400).json({ error });
          });
    }
};



// exports.getCartItems = async (req, res) => {
//     try {

//         const cart = await Cart.findOne({ user: req.user._id })
//             .populate('cartItems.product', '_id name price productPictures')
//             .exec((error, cart) => {
//                 if (error) return res.status(500).json({ error });
//                 if (cart) {
//                     try {
//                         let cartItems = {};
//                         cart.cartItems.forEach((item, index) => {
//                             cartItems[item.product._id.toString()] = {
//                                 _id: item.product._id.toString(),
//                                 name: item.product.name,
//                                 img: item.product.productPictures[0].img,
//                                 price: item.product.price,
//                                 qty: item.quantity,
//                             }
//                         })
//                          res.status(200).json({ cartItems })
//                     } catch (e) {
//                         res.status(400).json({ message: "that's not okay" })
//                     }
//                 }   
//             })
//     } catch (error) {
//         if (error) return res.status(600).json({ error });
//     }
// };

// exports.removeCartItems = (req, res) => {
//     const { productId } = req.body.payload;
//     if (productId) {
//       Cart.update(
//         { user: req.user._id },
//         {
//           $pull: {
//             cartItems: {
//               product: productId,
//             },
//           },
//         }
//       ).exec((error, result) => {
//         if (error) return res.status(400).json({ error });
//         if (result) {
//           res.status(202).json({ result });
//         }
//       });
//     }
//   };