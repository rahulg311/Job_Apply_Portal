const applicantEducation = require('../models/education');

exports.addEducation = (req,res) => {
    const { payload } = req.body;
    if(payload.education){
        if(payload.education._id){
            console.log("education-------4",payload.education._id)

            applicantEducation.findOneAndUpdate(
                { user: req.user._id, "education._id": payload.education._id }, 
                {
                    $set: {
                        "education.$": payload.education
                    },
                }
            ).then((education) => {
                console.log("education-------5",education)

                if(education){
                    res.status(200).json({ education });
                }
            }).catch((error) => {
                console.log("education-------6",error)
                if(error) return res.status(400).json({ error });
            });; 
        }else{
            console.log("education-------1", payload.education)
            applicantEducation.findOneAndUpdate(
                { user: req.user._id }, 
                {
                    $push: {
                        education: payload.education
                    },
                },
                { new: true, upsert: true }
            ).then((education) => {
                console.log("education-------2",education)
                if(education){
                    res.status(200).json({ education });
                }
            }).catch((error) => {
                console.log("education-------3",education)
                if(error) return res.status(400).json({ error });
            });
        }
        
    }else{
        res.status(400).json({ error: 'params education required'});
    }
}

exports.getEducation = (req, res) => {
    applicantEducation.findOne({ user: req.user._id })
    .exec((error, applicantEducation) => {
        if(error) return res.status(400).json({ error });
        if(applicantEducation){
            res.status(200).json({ applicantEducation });
        }
    }) ;
}